(() => {
  fetch(
    "https://script.google.com/macros/s/AKfycbzolAPaiLFW2ivDuzP97r6CIWLu1iVewawRMb7bqnNcJ7UkQv-3/exec"
  )
    .then((response) => {
        response.json().then((result) => {
            var obj = result;
            var key_section_html =  '<h1>KEY</h1>';
            var key_values = Object.keys(obj);
            const key_section = document.getElementsByClassName('key_section')[0];
            for(var i = 0; i < key_values.length; i++) {
                var name = key_values[i];
                key_section_html += '<div class="key_list">'+
                                    '<div class="left">'+
                                    name +
                                    '</div>'+
                                    '<div class="right">'+
                                    '<img src="./assets/images/Bookstore.png" alt="">'+
                                    '</div>'+
                                    '</div>';
            }
            key_section.innerHTML = key_section_html;
        });
    })
    .catch((e) => {
        console.log(e);
    });
})();
